import { createFileRoute, Link } from '@tanstack/react-router';
import { ArrowLeft, CheckCircle2, Store } from 'lucide-react';
import { useState, type FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { DemoNotice, PageHeading } from '@/components/PowerGo';

export const Route = createFileRoute('/stationen/anbieten')({
  head: () => ({
    meta: [
      { title: 'Ladestation anbieten — PowerGo' },
      { name: 'description', content: 'Registriere dein Geschäft und biete eine PowerGo-Ladestation für Powerbanks an.' },
      { property: 'og:title', content: 'Ladestation anbieten — PowerGo' },
      { property: 'og:description', content: 'Werde PowerGo-Partner und biete Powerbanks in deinem Geschäft an.' },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
  }),
  component: AddStation,
});

type Form = { business: string; type: string; address: string; area: string; hours: string; slots: string; landmark: string; email: string };
const empty: Form = { business: '', type: 'Café', address: '', area: '', hours: '', slots: '6', landmark: '', email: '' };

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block"><span className="mb-2 block text-sm font-semibold">{label}</span>{children}</label>;
}

function AddStation() {
  const [form, setForm] = useState<Form>(empty);
  const [sent, setSent] = useState(false);
  const set = (k: keyof Form) => (e: { target: { value: string } }) => setForm({ ...form, [k]: e.target.value });
  const submit = (e: FormEvent) => { e.preventDefault(); setSent(true); };

  if (sent) return <main className="page-wrap min-h-[70vh] py-16"><div className="mx-auto max-w-xl text-center"><CheckCircle2 className="mx-auto size-16 text-brand" /><h1 className="heading-xl mt-6">Danke, {form.business}!</h1><p className="mt-4 text-lg text-muted-foreground">So würde deine Anfrage aussehen. In dieser Vorschau wird noch nichts gespeichert – die Station erscheint deshalb nicht in der Liste.</p><div className="mt-8 rounded-lg border border-border bg-card p-6 text-left text-sm"><p><b>Art:</b> {form.type}</p><p className="mt-1"><b>Adresse:</b> {form.address}{form.area && ` (${form.area})`}</p><p className="mt-1"><b>Öffnungszeiten:</b> {form.hours}</p><p className="mt-1"><b>Ladeplätze:</b> {form.slots}</p>{form.landmark && <p className="mt-1"><b>Fundort:</b> {form.landmark}</p>}</div><div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center"><Button size="lg" variant="outline" onClick={() => { setForm(empty); setSent(false); }}>Weitere Station eintragen</Button><Button asChild size="lg"><Link to="/stationen">Zu den Stationen</Link></Button></div></div></main>;

  return <main className="page-wrap min-h-[70vh] py-12 md:py-16">
    <Link to="/stationen" className="inline-flex items-center gap-2 text-sm font-bold text-muted-foreground hover:text-brand"><ArrowLeft className="size-4" /> Alle Stationen</Link>
    <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_1.4fr]">
      <div><PageHeading eyebrow="Für Geschäfte" title="Ladestation anbieten" description="Du hast ein Café, einen Laden oder ein Büro? Biete deinen Kundinnen und Kunden Powerbanks zum Ausleihen an." /><div className="flex items-start gap-3 rounded-lg bg-brand-soft p-5"><Store className="mt-0.5 size-6 shrink-0 text-brand" /><p className="text-sm">Trage dein Geschäft ein. Nach einer Prüfung wird die Station für alle sichtbar.</p></div></div>
      <form onSubmit={submit} className="rounded-lg border border-border bg-card p-6 md:p-8">
        <DemoNotice />
        <div className="mt-6 grid gap-5 sm:grid-cols-2">
          <Field label="Name des Geschäfts"><input required className="field" value={form.business} onChange={set('business')} placeholder="z. B. Café Sonne" /></Field>
          <Field label="Art"><select className="field" value={form.type} onChange={set('type')}>{['Café', 'Restaurant', 'Laden', 'Büro', 'Hotel', 'Sonstiges'].map(t => <option key={t}>{t}</option>)}</select></Field>
          <div className="sm:col-span-2"><Field label="Adresse"><input required className="field" value={form.address} onChange={set('address')} placeholder="Straße, PLZ, Hannover" /></Field></div>
          <Field label="Stadtteil"><input className="field" value={form.area} onChange={set('area')} placeholder="z. B. Linden" /></Field>
          <Field label="Anzahl Ladeplätze"><input required type="number" min={1} max={50} className="field" value={form.slots} onChange={set('slots')} /></Field>
          <Field label="Öffnungszeiten"><input required className="field" value={form.hours} onChange={set('hours')} placeholder="z. B. Mo–Sa 08:00–20:00" /></Field>
          <Field label="Kontakt-E-Mail"><input required type="email" className="field" value={form.email} onChange={set('email')} placeholder="name@beispiel.de" /></Field>
          <div className="sm:col-span-2"><Field label="Wo steht die Station? (optional)"><input className="field" value={form.landmark} onChange={set('landmark')} placeholder="z. B. Neben der Kasse" /></Field></div>
        </div>
        <Button type="submit" variant="brand" size="lg" className="mt-8 w-full">Station eintragen</Button>
      </form>
    </div>
  </main>;
}
