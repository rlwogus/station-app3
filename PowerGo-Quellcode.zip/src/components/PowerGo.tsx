import { Link, useRouterState } from '@tanstack/react-router';
import { ArrowRight, BatteryCharging, CircleHelp, Clock3, MapPin, Menu, UserRound, X, Zap } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import type { Station } from '@/lib/powergo-data';

const nav = [
  { label: 'Stationen', to: '/stationen' as const },
  { label: 'Meine Ausleihen', to: '/ausleihen' as const },
  { label: 'So funktioniert’s', to: '/hilfe' as const },
];

export function Brand() {
  return <Link to="/" className="inline-flex items-center gap-2.5 font-display text-xl font-bold text-foreground" aria-label="PowerGo Startseite"><span className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground"><Zap className="size-5 fill-current" /></span>Power<span className="text-brand">Go</span></Link>;
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return <header className="relative z-30 border-b border-border bg-background/95">
    <div className="page-wrap flex h-20 items-center justify-between gap-6">
      <Brand />
      <nav className="hidden items-center gap-9 md:flex" aria-label="Hauptnavigation">{nav.map((item) => <Link key={item.to} to={item.to} className={`text-sm font-semibold transition-colors hover:text-brand ${pathname.startsWith(item.to) ? 'text-brand' : 'text-muted-foreground'}`}>{item.label}</Link>)}</nav>
      <div className="hidden items-center gap-3 md:flex"><Button asChild variant="ghost" size="lg"><Link to="/profil" aria-label="Profil"><UserRound /> Profil</Link></Button><Button asChild size="lg"><Link to="/login">Anmelden <ArrowRight /></Link></Button></div>
      <Button variant="ghost" size="icon" className="md:hidden" aria-label={open ? 'Menü schließen' : 'Menü öffnen'} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</Button>
    </div>
    {open && <nav className="page-wrap flex flex-col gap-1 border-t border-border py-4 md:hidden" aria-label="Mobile Navigation">{nav.map((item) => <Link onClick={() => setOpen(false)} key={item.to} to={item.to} className="rounded-md px-3 py-3 font-semibold hover:bg-secondary">{item.label}</Link>)}<Link onClick={() => setOpen(false)} to="/profil" className="rounded-md px-3 py-3 font-semibold hover:bg-secondary">Profil</Link><Link onClick={() => setOpen(false)} to="/login" className="rounded-md px-3 py-3 font-semibold hover:bg-secondary">Anmelden / Registrieren</Link></nav>}
  </header>;
}

export function SiteFooter() {
  return <footer className="border-t border-border bg-secondary"><div className="page-wrap grid gap-8 py-12 md:grid-cols-3 md:items-center"><Brand /><p className="text-sm text-muted-foreground">Energie für unterwegs. Genau dann, wenn du sie brauchst.</p><div className="flex flex-wrap gap-5 text-sm font-medium md:justify-end"><Link to="/stationen" className="hover:text-brand">Stationen</Link><Link to="/hilfe" className="hover:text-brand">Hilfe</Link><Link to="/profil" className="hover:text-brand">Profil</Link></div></div></footer>;
}

export function DemoNotice() { return <div className="demo-notice"><span className="size-2 rounded-full bg-brand" /> Vorschau mit Beispieldaten · Noch keine echte Ausleihe oder Anmeldung</div>; }

export function PageHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description?: string }) { return <div className="mb-9"><p className="eyebrow">{eyebrow}</p><h1 className="heading-xl mt-3">{title}</h1>{description && <p className="mt-4 max-w-2xl text-lg text-muted-foreground">{description}</p>}</div>; }

export function StationCard({ station }: { station: Station }) {
  return <article className="station-card flex h-full flex-col justify-between p-6"><div><div className="mb-6 flex items-start justify-between gap-3"><span className="icon-box"><MapPin className="size-5" /></span><span className={`status-pill ${station.available ? 'status-available' : 'status-empty'}`}><span className="size-1.5 rounded-full bg-current" />{station.available ? `${station.available} verfügbar` : 'Keine verfügbar'}</span></div><p className="text-xs font-bold uppercase text-muted-foreground">{station.area} · {station.distance}</p><h3 className="mt-2 font-display text-2xl font-bold">{station.name}</h3><p className="mt-2 text-sm text-muted-foreground">{station.address}</p></div><div className="mt-7 flex items-center justify-between border-t border-border pt-5"><span className="inline-flex items-center gap-2 text-sm text-muted-foreground"><BatteryCharging className="size-4" /> {station.available} von {station.total} frei</span><Link className="inline-flex items-center gap-1 text-sm font-bold text-brand hover:underline" to="/stationen/$stationId" params={{ stationId: station.id }}>Details <ArrowRight className="size-4" /></Link></div></article>;
}

export function StatLine({ icon: Icon, label, value }: { icon: typeof Clock3; label: string; value: string }) { return <div className="flex items-start gap-3 py-4"><Icon className="mt-0.5 size-5 shrink-0 text-brand" /><div><p className="text-sm text-muted-foreground">{label}</p><p className="mt-1 font-semibold">{value}</p></div></div>; }

export { ArrowRight, BatteryCharging, CircleHelp, Clock3, MapPin, UserRound, Zap };
