export type Station = { id: string; name: string; address: string; area: string; available: number; total: number; distance: string; hours: string; landmark: string; lat: number; lng: number };
export const stations: Station[] = [
  { id: 'kroepcke', name: 'Kröpcke', address: 'Kröpcke, 30159 Hannover', area: 'Mitte', available: 8, total: 12, distance: '0,3 km', hours: 'Täglich 06:00–23:00', landmark: 'Am Kröpcke (Beispielstandort)', lat: 52.3741, lng: 9.7387 },
  { id: 'hauptbahnhof', name: 'Hauptbahnhof', address: 'Ernst-August-Platz, 30159 Hannover', area: 'Mitte', available: 5, total: 10, distance: '0,6 km', hours: 'Täglich 07:00–22:00', landmark: 'Am Ernst-August-Platz (Beispielstandort)', lat: 52.3765, lng: 9.7414 },
  { id: 'maschsee', name: 'Maschsee Nordufer', address: 'Arthur-Menge-Ufer, 30169 Hannover', area: 'Südstadt', available: 3, total: 8, distance: '1,6 km', hours: 'Täglich 08:00–22:00', landmark: 'Am Nordufer (Beispielstandort)', lat: 52.3632, lng: 9.7395 },
  { id: 'kuechengarten', name: 'Küchengarten', address: 'Küchengarten, 30449 Hannover', area: 'Linden', available: 0, total: 10, distance: '2,4 km', hours: 'Rund um die Uhr', landmark: 'Am Küchengarten (Beispielstandort)', lat: 52.3712, lng: 9.7159 },
];
export const getStation = (id: string) => stations.find((station) => station.id === id);
